// This file is deleted. The calculatedCharacter slice is being removed.
// The characterDataReducer from engine/characterReducer.ts remains as the source of truth.
