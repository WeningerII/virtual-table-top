
import { CrucibleAction } from "./crucibleActions";

export type SimulationAction = CrucibleAction;
