
import React from 'react';
import { useAppSelector, useAppDispatch } from '../../state/hooks';
import { createCharacter, loadCharacter, deleteCharacter, rosterSelectors } from '../../state/rosterSlice';
import { selectCalculatedActiveCharacterSheet } from '../../state/selectors';
import HomeView from '../home/HomeView';
import GenesisView from '../genesis/GenesisView';
import BuilderView from '../BuilderView';
import { PlayView } from '../play/PlayView';
import BestiaryView from '../bestiary/BestiaryView';
import WorldbuilderView from '../worldbuilder/WorldbuilderView';
import CrucibleView from '../crucible/CrucibleView';
import { AppMode } from '../../types';

const AppRouter: React.FC = () => {
    const dispatch = useAppDispatch();
    const mode = useAppSelector(state => state.app.mode);
    const roster = useAppSelector(rosterSelectors.selectAll);
    const character = useAppSelector(selectCalculatedActiveCharacterSheet);

    const handleCreateCharacter = () => {
        dispatch(createCharacter());
    };

    const handleLoadCharacter = (id: string) => {
        dispatch(loadCharacter(id));
    };

    const handleDeleteCharacter = (id: string) => {
        if (window.confirm("Are you sure you want to permanently delete this character?")) {
            dispatch(deleteCharacter(id));
        }
    };
    
    const homeProps = { roster, onCreate: handleCreateCharacter, onLoad: handleLoadCharacter, onDelete: handleDeleteCharacter };

    const routeMap: Record<AppMode, () => React.ReactNode> = {
        home: () => <HomeView {...homeProps} />,
        genesis: () => <GenesisView />,
        builder: () => character ? <BuilderView /> : <div className="text-center p-8">Please create or load a character to use the builder.</div>,
        play: () => character ? <PlayView /> : <div className="text-center p-8">Please select a character to play.</div>,
        bestiary: () => <BestiaryView />,
        worldbuilder: () => <WorldbuilderView />,
        crucible: () => <CrucibleView />,
    };

    const CurrentView = routeMap[mode] || routeMap.home;
    
    return <CurrentView />;
};

export default AppRouter;
